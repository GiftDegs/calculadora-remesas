// Detectar configuración regional
const userLocale = navigator.language || 'es-ES';

// Config USD y número de WhatsApp
const CONFIG = { MIN_USD: 5, MAX_USD: 1000 };
const NUMERO_WHATSAPP = '5491157261053';

// Estados globales
let aceptoAdvertenciaPartes = false;
let origenSeleccionado = null;
let destinoSeleccionado = null;
let mode = null;
let tasa = null;
let tasaCompraUSD = null;
let estadoActual = 'origen';
let lastCalc = null;
let tasaConfirmacionTimer = null;
let tasaConfirmacionHideAnimTimer = null;
let tasaDesactualizada = false;
let __h2cPromise = null;


// Elementos DOM
const btnVolverGlobal = document.getElementById('btnVolverGlobal');
const mainHeader = document.getElementById('mainHeader');
const subtituloHeader = document.getElementById('subtituloHeader');
const tasaValue = document.getElementById('tasaValue');
const tasaFechaEl = document.getElementById('tasaFecha');
const step1Origen = document.getElementById('step1Origen');
const origenBtns = document.getElementById('origenBtns');
const step2Destino = document.getElementById('step2Destino');
const destinoBtns = document.getElementById('destinoBtns');
const tasaWrap = document.getElementById('tasaWrap');
const step1 = document.getElementById('step1');
const step2 = document.getElementById('step2');
const resultado = document.getElementById('resultado');
const btnEnviar = document.getElementById('btnEnviar');
const btnLlegar = document.getElementById('btnLlegar');
const preguntaMonto = document.getElementById('preguntaMonto');
const inputMonto = document.getElementById('inputMonto');
const errorMonto = document.getElementById('errorMonto');
const btnCalcular = document.getElementById('btnCalcular');
const btnRecalcular = document.getElementById('btnRecalcular');
const loader = document.getElementById('calculando');
const resText = document.getElementById('resText');
const soundSuccess = document.getElementById('soundSuccess');
const btnWhats = document.getElementById('btnWhats');
const btnCompartir = document.getElementById('btnCompartir');
const resTextContainer = document.getElementById('resTextContainer');
const opcionTexto = document.getElementById('opcionTexto');
const opcionImagen = document.getElementById('opcionImagen');
const toastMensaje = document.getElementById('toastMensaje');
const btnToggleDark = document.getElementById('toggleDark');
const ayudaMonto = document.getElementById('ayudaMonto');
const tasaConfirmacion = document.getElementById('tasaConfirmacion');
const tasaConfirmacionTexto = document.getElementById('tasaConfirmacionTexto');
const tasaAdvertencia = document.getElementById('tasaAdvertencia');
const tasaAdvertenciaTexto = document.getElementById('tasaAdvertenciaTexto');
const tasaCard = document.getElementById('tasaCard');

function resetearCampoMonto() {
  inputMonto.value = '';
  errorMonto.classList.add('hidden');
  // estilo neutral sin borrar los rangos (setInputStyle no recibe msg)
  setInputStyle({ state: 'neutral' });
  updateAyudaRangos(); // muestra mínimo/máximo actualizados
}

// Normaliza timestamps del backend (segundos o string ISO) a milisegundos
function normalizarTimestamp(ts) {
  if (!ts) return null;
  const n = Number(ts);
  if (Number.isFinite(n)) {
    // si es < 1e12, asumimos segundos y lo llevamos a ms
    return n < 1e12 ? n * 1000 : n;
  }
  const parsed = Date.parse(ts);
  return Number.isFinite(parsed) ? parsed : null;
}

// --- Conversión de límites USD a la moneda del INPUT ---
function convertirDesdePesosOrigenAInput(montoEnPesosOrigen) {
  if (!mode) return null; // sin modo no sabemos cuál es la moneda del input
  if (mode === 'enviar') {
    // El input está en moneda de ORIGEN
    return montoEnPesosOrigen;
  }
  // El input está en moneda de DESTINO → ¿cuánto llegaría si envío ese monto?
  if (!tasa || !Number.isFinite(parseFloat(tasa))) return null;
  return calcularCruce(origenSeleccionado, destinoSeleccionado, 'enviar', montoEnPesosOrigen, parseFloat(tasa));
}

// Retorna {min, max} en la moneda del INPUT (o null si no se puede calcular)
function rangoPermitidoEnInput() {
  if (!mode || !tasaCompraUSD) return null;

  const minPesosOrigen = CONFIG.MIN_USD * tasaCompraUSD;
  const maxPesosOrigen = CONFIG.MAX_USD * tasaCompraUSD;

  const minInput = convertirDesdePesosOrigenAInput(minPesosOrigen);
  const maxInput = convertirDesdePesosOrigenAInput(maxPesosOrigen);

  if (!Number.isFinite(minInput) || !Number.isFinite(maxInput)) return null;
  return { min: minInput, max: maxInput };
}

// Muestra en ayudaMonto el rango permitido anticipadamente
function updateAyudaRangos() {
  const o = obtenerPais(origenSeleccionado);
  const d = obtenerPais(destinoSeleccionado);
  const codigoInput = mode === 'llegar' ? (d?.codigo ?? '') : (o?.codigo ?? '');

  // Caso sin modo aún
  if (!mode) {
    ayudaMonto.textContent = '';
    return;
  }

  // Si el input es en ORIGEN (modo "enviar") podemos calcular con solo tasaCompraUSD
  if (mode === 'enviar' && !tasaCompraUSD) {
    ayudaMonto.textContent = 'Calculando límites...';
    return;
  }

  // Si el input es en DESTINO (modo "llegar") necesitamos además la tasa de cruce
  if (mode === 'llegar' && (!tasaCompraUSD || !tasa)) {
    ayudaMonto.textContent = 'Esperando tasa para calcular límites...';
    return;
  }

  const rango = rangoPermitidoEnInput();
  if (!rango) {
    ayudaMonto.textContent = '';
    return;
  }

  const nf = new Intl.NumberFormat(userLocale, { maximumFractionDigits: 2 });
  const minFmt = nf.format(Math.max(0, rango.min));
  const maxFmt = nf.format(Math.max(rango.min, rango.max));

  ayudaMonto.textContent = `Mínimo: ${minFmt} ${codigoInput} • Máximo: ${maxFmt} ${codigoInput}`;
}


function ensureHtml2Canvas() {
  // Si ya está disponible en window, listo
  if (window.html2canvas) return Promise.resolve(window.html2canvas);

  // Evita inyectar 2 veces si ya está cargando
  if (__h2cPromise) return __h2cPromise;

  __h2cPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js';
    s.async = true;
    s.onload = () => resolve(window.html2canvas);
    s.onerror = () => {
      __h2cPromise = null; // permitir reintentar
      reject(new Error('No se pudo cargar html2canvas'));
    };
    document.head.appendChild(s);
  });

  return __h2cPromise;
}

function setModoButtonsEnabled(enabled) {
  [btnEnviar, btnLlegar].forEach(b => {
    b.disabled = !enabled;
    b.classList.toggle('opacity-50', !enabled);
    b.classList.toggle('cursor-not-allowed', !enabled);
    b.classList.toggle('hover:scale-105', enabled);
  });
}


function showBanner(el) {
  el.classList.remove('hidden','opacity-0','pointer-events-none','translate-y-1');
  el.classList.add('opacity-100','translate-y-0');
}

function hideBanner(el) {
  el.classList.add('opacity-0','pointer-events-none','translate-y-1');
  el.classList.remove('opacity-100');
}

function mostrarConfirmacionVerdeAutoOcultar(msVisible = 4000) {
  // limpiamos timers previos
  if (tasaConfirmacionTimer) clearTimeout(tasaConfirmacionTimer);
  if (tasaConfirmacionHideAnimTimer) clearTimeout(tasaConfirmacionHideAnimTimer);

  // preparar estado visible + animación de entrada
  tasaConfirmacion.classList.remove('hidden', 'confirm-out', 'confirm-in', 'confirm-blink');
  // truco para reiniciar la animación
  void tasaConfirmacion.offsetWidth;
  tasaConfirmacion.classList.add('confirm-in', 'confirm-blink');
  showBanner(tasaConfirmacion);
      

  // auto-ocultar con animación de salida
  tasaConfirmacionTimer = setTimeout(() => {
    tasaConfirmacion.classList.remove('confirm-blink', 'confirm-in');
    tasaConfirmacion.classList.add('confirm-out');
    tasaConfirmacionHideAnimTimer = setTimeout(() => {
       hideBanner(tasaConfirmacion);
      tasaConfirmacion.classList.remove('confirm-out');
    }, 260);
  }, msVisible);
}

function ocultarConfirmacionVerdeInmediato() {
  if (tasaConfirmacionTimer) clearTimeout(tasaConfirmacionTimer);
  if (tasaConfirmacionHideAnimTimer) clearTimeout(tasaConfirmacionHideAnimTimer);
  hideBanner(tasaConfirmacion);
  tasaConfirmacion.classList.remove('confirm-in', 'confirm-out', 'confirm-blink');
}

function obtenerPais(cod) {
  return paisesDisponibles.find(p => p.codigo === cod);
}

function setTheme(isDark) {
  if (isDark) {
    document.documentElement.classList.add('dark');
    localStorage.setItem('theme', 'dark');
    btnToggleDark.textContent = '🌞 Claro';
  } else {
    document.documentElement.classList.remove('dark');
    localStorage.setItem('theme', 'light');
    btnToggleDark.textContent = '🌙 Oscuro';
  }
}

// Devuelve textos consistentes según origen/destino
function textosSegunPaises() {
  const o = obtenerPais(origenSeleccionado);
  const d = obtenerPais(destinoSeleccionado);

  if (!o || !d) {
    return {
      btnEnviar: '¿Cuánto dinero quieres enviar?',
      btnLlegar: '¿Cuánto quieres que llegue?',
      preguntaEnviar: '¿Cuánto vas a enviar?',
      preguntaLlegar: '¿Cuánto quieres que llegue?'
    };
  }

  return {
    btnEnviar: `¿Cuántos ${o.moneda} quieres enviar?`,
    btnLlegar: `¿Cuántos ${d.moneda} quieres que lleguen?`,
    preguntaEnviar: `¿Cuántos ${o.moneda} vas a enviar?`,
    preguntaLlegar: `¿Cuántos ${d.moneda} quieres que lleguen?`
  };
}

function actualizarTextosUI() {
  const { btnEnviar: tEnviar, btnLlegar: tLlegar } = textosSegunPaises();
  btnEnviar.textContent = tEnviar;
  btnLlegar.textContent = tLlegar;

  const o = obtenerPais(origenSeleccionado);
  const d = obtenerPais(destinoSeleccionado);
  const subtitulo = document.querySelector('header p');
  if (o && d && subtitulo) {
    subtitulo.textContent = `De ${o.nombre} (${o.moneda}) a ${d.nombre} (${d.moneda})`;
  }
}

// --- Máximo permitido en la MONEDA DEL INPUT (según modo actual) ---
function maxPermitidoEnInput() {
  // Necesitamos tener elegido el modo y cargado el costo del USD en moneda de origen
  if (!mode || !tasaCompraUSD) return null;

  // Máximo que puede ENVIARSE en moneda de ORIGEN para no superar 1000 USD
  const maxPesosOrigen = CONFIG.MAX_USD * tasaCompraUSD;

  if (mode === 'enviar') {
    // El input está en moneda de ORIGEN
    return maxPesosOrigen;
  }

  // Si el input es "llegar", está en moneda de DESTINO → convertimos
  if (!tasa || !Number.isFinite(parseFloat(tasa))) return null;

  // ¿Cuánto puede LLEGAR si envío el máximo permitido en origen?
  return calcularCruce(
    origenSeleccionado,
    destinoSeleccionado,
    'enviar',               // calculamos "enviar" → "llegar"
    maxPesosOrigen,
    parseFloat(tasa)
  );
}

// Estado inicial del texto del botón (según clase actual en <html>)
(function initThemeButtonLabel() {
  const isDark = document.documentElement.classList.contains('dark');
  btnToggleDark.textContent = isDark ? '🌞 Claro' : '🌙 Oscuro';
})();

btnToggleDark.addEventListener('click', () => {
  const isDark = document.documentElement.classList.toggle('dark');
  // Guardamos la preferencia
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  // Actualizamos etiqueta
  btnToggleDark.textContent = isDark ? '🌞 Claro' : '🌙 Oscuro';
});

function actualizarHeader(texto = '') {
  subtituloHeader.textContent = texto;
  mainHeader.classList.remove('hidden');
}

// Países y monedas
const paisesDisponibles = [
  { codigo: 'ARS', nombre: 'Argentina', emoji: '🇦🇷', moneda: 'pesos argentinos' },
  { codigo: 'COP', nombre: 'Colombia', emoji: '🇨🇴', moneda: 'pesos colombianos' },
  { codigo: 'PEN', nombre: 'Perú', emoji: '🇵🇪', moneda: 'soles' },
  { codigo: 'CLP', nombre: 'Chile', emoji: '🇨🇱', moneda: 'pesos chilenos' },
  { codigo: 'MXN', nombre: 'México', emoji: '🇲🇽', moneda: 'pesos mexicanos' },
  { codigo: 'BRL', nombre: 'Brasil', emoji: '🇧🇷', moneda: 'reales' },
  { codigo: 'VES', nombre: 'Venezuela', emoji: '🇻🇪', moneda: 'bolívares' }
];

// --- Utilidades ---
function calcularCruce(origen, destino, modo, monto, tasa) {
  const esColAVen = origen === 'COP' && destino === 'VES';
  if (modo === 'enviar') {
    return esColAVen ? monto / tasa : monto * tasa;
  } else {
    return esColAVen ? monto * tasa : monto / tasa;
  }
}

function formatearFecha(timestamp) {
  if (!timestamp) return 'hoy';
  const d = new Date(timestamp);
  if (isNaN(d)) return 'hoy';
  return d.toLocaleDateString(userLocale, { day:'2-digit', month:'long', year:'numeric' });
}

function redondearPorMoneda(valor, moneda) {
  let unidadRedondeo = 1;
  switch (moneda) {
    case 'ARS':
    case 'COP':
    case 'CLP':
      unidadRedondeo = 100; break;
    case 'VES':
    case 'MXN':
    case 'PEN':
    case 'BRL':
      unidadRedondeo = 1; break;
  }
  if (valor < unidadRedondeo) return Math.round(valor);
  const resto = valor % unidadRedondeo;
  return resto >= unidadRedondeo / 2 ? valor + (unidadRedondeo - resto) : valor - resto;
}

function formatearTasa(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return "-";
  if (n >= 1) return n.toFixed(1);
  if (n >= 0.01) return n.toFixed(3);
  if (n >= 0.00099) return n.toFixed(5);
  return n.toFixed(6);
}


// --- Carga de tasas desde backend ---
// Nota IMPORTANTE: La tasa SOLO se obtiene en vivo desde el backend.
// No se usa caché ni reintentos automáticos para evitar mostrar datos desactualizados.
// La actualización de tasas se gestiona manualmente desde el panel de administración.
// Si la tasa está desactualizada (+1 día) o no se puede obtener por red,
// el sistema bloquea la operación hasta que se actualice en el backend.


async function obtenerTasa(origen, destino) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  try {
    const res = await fetch('/api/snapshot', { cache: 'no-store', signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    const clave = `${origen}-${destino}`;
    const tasaCrudo = data?.cruces?.[clave] ?? null;

    const compra = Number(data?.[origen]?.compra);
    if (Number.isFinite(compra)) {
      tasaCompraUSD = compra; // global
    } else {
      console.warn(`No hay 'compra' USD para ${origen} en snapshot`);
    }

    return { tasa: tasaCrudo, fecha: normalizarTimestamp(data?.timestamp) };
  } catch (err) {
    console.error('Error al obtener tasa:', err);
    return { tasa: null, fecha: null };
  } finally {
    clearTimeout(timer);
  }
}

// --- UI Flow ---
function ocultarTodo() {
  step1Origen.classList.add('hidden');
  step2Destino.classList.add('hidden');
  step1.classList.add('hidden');
  step2.classList.add('hidden');
  tasaWrap.classList.add('hidden');
  resultado.classList.add('hidden');
}

function mostrarPaso1() {
  estadoActual = 'origen';
  ocultarTodo();
  step1Origen.classList.remove('hidden');
  actualizarHeader('Selecciona el país de origen');
  btnVolverGlobal.classList.add('hidden');
  step1Origen.classList.add('fade-slide-in');

  origenBtns.innerHTML = '';
  paisesDisponibles.forEach(pais => {
    const btn = document.createElement('button');
    btn.textContent = `${pais.emoji} ${pais.nombre}`;
    btn.className = 'ripple-button bg-white dark:bg-gray-100 border border-[#0066FF] text-[#0066FF] font-semibold px-6 py-3 rounded-xl shadow transition hover:scale-105';
    btn.onclick = () => { origenSeleccionado = pais.codigo; mostrarPaso2(); };
    origenBtns.appendChild(btn);
  });
}

function mostrarPaso2() {
  estadoActual = 'destino';
  ocultarTodo();
  step2Destino.classList.remove('hidden');
  actualizarHeader('Selecciona el país destino');
  btnVolverGlobal.classList.remove('hidden');
  step2Destino.classList.add('fade-slide-in');

  destinoBtns.innerHTML = '';
  paisesDisponibles
    .filter(p => p.codigo !== origenSeleccionado)
    .forEach(pais => {
      const btn = document.createElement('button');
      btn.textContent = `${pais.emoji} ${pais.nombre}`;
      btn.className = 'ripple-button bg-white dark:bg-gray-100 border border-[#0066FF] text-[#0066FF] font-semibold px-6 py-3 rounded-xl shadow transition hover:scale-105';
      btn.onclick = () => { destinoSeleccionado = pais.codigo; step2Destino.classList.add('hidden'); mostrarPaso3(); };
      destinoBtns.appendChild(btn);
    });
}

async function mostrarPaso3() {
  estadoActual = 'modo';
  ocultarTodo();
  step1.classList.remove('hidden');
  btnVolverGlobal.classList.remove('hidden');
  mainHeader.classList.remove('hidden');
  tasaWrap.classList.remove('hidden');
  actualizarHeader('Selecciona el tipo de operación');

  const paisOrigen = paisesDisponibles.find(p => p.codigo === origenSeleccionado);
  const paisDestino = paisesDisponibles.find(p => p.codigo === destinoSeleccionado);
  const subtitulo = document.querySelector('header p');
  actualizarTextosUI();
  if (paisOrigen && paisDestino && subtitulo) {
    subtitulo.textContent = `De ${paisOrigen.nombre} (${paisOrigen.moneda}) a ${paisDestino.nombre} (${paisDestino.moneda})`;
  }

  const { tasa: tasaCruda, fecha } = await obtenerTasa(origenSeleccionado, destinoSeleccionado);

  // Aseguramos un chequeo numérico real de la tasa
  const tasaNum = Number(tasaCruda);
  const tieneTasa = Number.isFinite(tasaNum) && tasaNum > 0;

  if (tieneTasa) {
    // ✅ Tasa recibida
    tasa = tasaNum;
    tasaValue.textContent = formatearTasa(tasa);
    tasaFechaEl.textContent = formatearFecha(fecha);

    // ¿Está desactualizada (>1 día)?
    let diasDiferencia = 999;
    if (fecha) {
      const ahora = Date.now();
      const MS_DIA = 86400000;
      diasDiferencia = Math.floor((ahora - fecha) / MS_DIA);
    }

    if (diasDiferencia > 1) {
      // ⛔ Vieja -> bloquear
      tasaDesactualizada = true;
      ocultarConfirmacionVerdeInmediato();
      tasaAdvertenciaTexto.textContent = '🚨 Tasa desactualizada 🚨';
      showBanner(tasaAdvertencia);
      tasaAdvertencia.classList.add('animate-bounce');
      setTimeout(() => tasaAdvertencia.classList.remove('animate-bounce'), 1500);
    } else {
      // ✅ Al día -> habilitar
      tasaDesactualizada = false;
      hideBanner(tasaAdvertencia);
      tasaConfirmacionTexto.textContent = '✅ Tasa actualizada';
      mostrarConfirmacionVerdeAutoOcultar(4000);
    }

    setModoButtonsEnabled(!tasaDesactualizada);
    updateAyudaRangos();
    validarMontoEnVivo();

    // Efecto leve en el número
    tasaValue.classList.add('animate-pulse');
    setTimeout(() => tasaValue.classList.remove('animate-pulse'), 1000);

  } else {
    // ❌ Sin tasa -> rojo fijo y bloqueo
    tasaDesactualizada = true;
    setModoButtonsEnabled(false);
    tasaValue.textContent = '⚠️ No disponible';
    tasaFechaEl.textContent = '—';
    hideBanner(tasaConfirmacion);
    tasaAdvertenciaTexto.textContent = 'No hay tasa disponible';
    showBanner(tasaAdvertencia);

    updateAyudaRangos();
    validarMontoEnVivo();
  }
}


// ⛔ Corte de seguridad
// No se permite avanzar si la tasa está desactualizada.
// Esto asegura que los cálculos se hagan SOLO con datos confirmados
// desde el panel y evita usar tasas viejas por error o por fallo de red.

function cambiarPaso(tipo) {
 

  if (tasaDesactualizada) {
    mostrarToast('⚠️ No podés continuar: la tasa está desactualizada. Actualizá y volvé a intentar.');
    // Un pequeño “bounce” visual en la advertencia roja
    tasaAdvertencia.classList.add('animate-bounce');
    setTimeout(() => tasaAdvertencia.classList.remove('animate-bounce'), 800);
    return;
  }

  mode = tipo;
  estadoActual = 'monto';
  const { preguntaEnviar, preguntaLlegar } = textosSegunPaises();
  preguntaMonto.textContent = tipo === 'enviar' ? preguntaEnviar : preguntaLlegar;

  resetearCampoMonto();
  updateAyudaRangos();

  preguntaMonto.classList.remove('opacity-0','translate-y-4');
  preguntaMonto.classList.add('opacity-100','translate-y-0');
  step1.classList.add('hidden');
  step2.classList.remove('hidden');
  setTimeout(() => { inputMonto.focus(); validarMontoEnVivo(); }, 300);
}

btnEnviar.onclick = () => cambiarPaso('enviar');
btnLlegar.onclick = () => cambiarPaso('llegar');

btnVolverGlobal.onclick = () => {
  // Oculta errores si estaban visibles
  errorMonto.classList.add('hidden');

  switch (estadoActual) {
    case 'resultado':
      // Volver del resultado al ingreso de monto
      resultado.classList.add('hidden');
      resText.classList.remove('text-4xl');
      step2.classList.remove('hidden');
      tasaWrap.classList.remove('hidden');
      setTimeout(() => tasaWrap.classList.remove('opacity-0', 'scale-95'), 50);
      estadoActual = 'monto';
      actualizarHeader('Ingresa el monto');
      resetearCampoMonto();
      setTimeout(() => inputMonto.focus(), 200);
      break;

    case 'monto':
      // Volver del monto a elegir modo (enviar / llegar)
      step2.classList.add('hidden');
      step1.classList.remove('hidden');
      tasaWrap.classList.remove('hidden');
      setTimeout(() => tasaWrap.classList.remove('opacity-0', 'scale-95'), 50);
      estadoActual = 'modo';
      actualizarHeader('Selecciona el tipo de operación');
      break;

    case 'modo':
      // Volver a elegir destino
      mostrarPaso2();
      break;

    case 'destino':
      // Volver a elegir origen
      mostrarPaso1();
      break;

    case 'origen':
    default:
      // Ya estás en el primer paso
      btnVolverGlobal.classList.add('hidden');
      break;
  }
};

// --- Normalización + Tope por 1000 USD + Enter + Focus/Blur seguros ---
let scrollAntesDeTeclado = 0;

inputMonto.addEventListener('focus', () => {
  scrollAntesDeTeclado = window.scrollY;
  setTimeout(() => inputMonto.scrollIntoView({ behavior: 'smooth', block: 'center' }), 300);
  updateAyudaRangos();
});

inputMonto.addEventListener('blur', () => {
  // Oculto errores viejos pero NO limpio el input (evita perder el valor al hacer click en la UI)
  errorMonto.classList.add('hidden');
  setTimeout(() => window.scrollTo({ top: scrollAntesDeTeclado, behavior: 'smooth' }), 150);
});

inputMonto.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();      // evita submits raros
    btnCalcular.click();     // dispara el cálculo
    // NO limpiamos el input aquí
  }
});

inputMonto.addEventListener('input', () => {
  // 1) Normalizo: solo dígitos y 1 punto, máx 2 decimales
 let val = inputMonto.value
  .replace(/,/g, '.')     // antes era solo la primera coma
  .replace(/[^0-9.]/g, '');
  const parts = val.split('.');
  if (parts.length > 2) val = parts[0] + '.' + parts[1];
  if (parts[1]?.length > 2) val = parts[0] + '.' + parts[1].slice(0, 2);
  inputMonto.value = val;

  // 2) Tope dinámico equivalente a 1000 USD en la MONEDA del input
  const num = parseFloat(val);
  const maxVal = maxPermitidoEnInput();

  if (Number.isFinite(num) && Number.isFinite(maxVal) && num > maxVal) {
    // Trunco a 2 decimales para no pasarnos
    const capped = Math.floor(maxVal * 100) / 100;
    inputMonto.value = String(capped);
  }
});


function setInputStyle({ state, msg = null }) {
  // Limpio clases de color previas
  inputMonto.classList.remove('border-blue-300', 'border-green-500', 'border-red-500', 'focus:ring-blue-300', 'focus:ring-green-500', 'focus:ring-red-500');

  // ✅ Solo toco el texto de ayuda si me pasaron un msg explícito
  if (msg !== null) {
    ayudaMonto.textContent = msg;
  }

  if (state === 'neutral') {
    inputMonto.classList.add('border-blue-300', 'focus:ring-blue-300');
  } else if (state === 'ok') {
    inputMonto.classList.add('border-green-500', 'focus:ring-green-500');
  } else if (state === 'error') {
    inputMonto.classList.add('border-red-500', 'focus:ring-red-500');
  }
}


function validarMontoEnVivo() {
  const raw = inputMonto.value.trim();

  // Siempre refrescamos la ayuda anticipativa
  updateAyudaRangos();

  // Campo vacío → estado neutral, conservando los rangos
  if (!raw) {
    btnCalcular.disabled = true;
    setInputStyle({ state: 'neutral' });
    return;
  }

  const monto = parseFloat(raw);
  if (!Number.isFinite(monto) || monto <= 0) {
    btnCalcular.disabled = true;
    setInputStyle({ state: 'error', msg: 'Ingresa un número mayor que 0.' });
    return;
  }

  // ✅ Habilitar "Calcular" SOLO cuando todo esté listo:
  const tasaNum = Number(tasa);
  const listoParaCalcular =
    !!mode &&
    Number.isFinite(tasaCompraUSD) &&
    Number.isFinite(tasaNum) && tasaNum > 0;

  if (!listoParaCalcular) {
    btnCalcular.disabled = true;
    setInputStyle({ state: 'neutral' });
    return;
  }

  // Para validar límites en USD necesito el monto en moneda de ORIGEN
  let montoEnPesosOrigen;
  if (mode === 'enviar') {
    montoEnPesosOrigen = monto;
  } else {
    montoEnPesosOrigen = calcularCruce(
      origenSeleccionado, destinoSeleccionado, mode, monto, tasaNum
    );
  }

  const montoUSD = montoEnPesosOrigen / tasaCompraUSD;

  // Reglas de rango (errores con mensaje explícito)
  if (montoUSD < CONFIG.MIN_USD) {
    btnCalcular.disabled = true;
    setInputStyle({
      state: 'error',
      msg: `El mínimo equivalente es ${CONFIG.MIN_USD} USD (ahora llevas ~${montoUSD.toFixed(2)} USD).`
    });
    return;
  }

  if (montoUSD > CONFIG.MAX_USD) {
    btnCalcular.disabled = true;
    setInputStyle({
      state: 'error',
      msg: `El máximo equivalente es ${CONFIG.MAX_USD} USD (ahora llevas ~${montoUSD.toFixed(2)} USD).`
    });
    return;
  }

  // Aviso informativo si supera 300 USD (no bloquea, se ve junto a los rangos)
  if (montoUSD >= 300) {
    const info = 'ℹ️ Montos mayores a 300 USD se envían en varias partes.';
    if (!ayudaMonto.textContent.includes('se envían en varias partes')) {
      ayudaMonto.textContent = ayudaMonto.textContent
        ? `${ayudaMonto.textContent}\n${info}`
        : info;
    }
  }

  // Todo OK → habilitar y no tocar los rangos
  btnCalcular.disabled = false;
  setInputStyle({ state: 'ok' });
}



// Hook: validar mientras escribe y cuando cambia el modo/paso
inputMonto.addEventListener('input', validarMontoEnVivo);


// --- Calcular ---
btnCalcular.onclick = () => {
  const raw = inputMonto.value.trim();
  const monto = parseFloat(raw);
  const tasaF = parseFloat(tasa);

  estadoActual = 'resultado';
  btnVolverGlobal.classList.remove('hidden');

  if (isNaN(monto)) {
    errorMonto.textContent = '⚠️ Ingresa un número válido';
    errorMonto.classList.remove('hidden');
    return;
  }
  if (isNaN(tasaF) || tasaF <= 0) {
    errorMonto.textContent = '⚠️ Tasa No Disponible.';
    errorMonto.classList.remove('hidden');
    return;
  }
  if (!tasaCompraUSD) {
    errorMonto.textContent = '⚠️ No se pudo obtener la tasa de compra en USD.';
    errorMonto.classList.remove('hidden');
    return;
  }

  const montoEnPesos = mode === 'enviar' ? monto : calcularCruce(origenSeleccionado, destinoSeleccionado, mode, monto, tasaF);
  const montoUSD = montoEnPesos / tasaCompraUSD;

  if (montoUSD < CONFIG.MIN_USD) {
    errorMonto.textContent = `⚠️ El monto mínimo permitido es equivalente a ${CONFIG.MIN_USD} USD`;
    errorMonto.classList.remove('hidden');
    return;
  }
  if (montoUSD > CONFIG.MAX_USD) {
    errorMonto.textContent = `⚠️ El monto máximo permitido es equivalente a ${CONFIG.MAX_USD} USD`;
    errorMonto.classList.remove('hidden');
    return;
  }

  // ⚠️ Eliminado el flujo de "Leí y acepto".
  // Si quieres dejar un recordatorio visual, puedes mostrar un toast suave:
  if (montoUSD >= 300) {
    mostrarToast('ℹ️ Montos mayores a 300 USD se envían en varias partes.');
  }

  errorMonto.classList.add('hidden');

  const calc = Math.round(calcularCruce(origenSeleccionado, destinoSeleccionado, mode, monto, tasaF));
  const paisOrigen = paisesDisponibles.find(p => p.codigo === origenSeleccionado);
  const paisDestino = paisesDisponibles.find(p => p.codigo === destinoSeleccionado);

  const calcRedondeado = mode === 'llegar' ? redondearPorMoneda(calc, paisOrigen.codigo) : calc;

  const fecha = tasaFechaEl.textContent;
  const montoFmt = new Intl.NumberFormat(userLocale, { maximumFractionDigits: 2 }).format(monto);
  const calcFmt = new Intl.NumberFormat(userLocale, { maximumFractionDigits: 0 }).format(calcRedondeado);
  const tasaFmt = formatearTasa(tasa);

  lastCalc = {
    mode,
    origen: paisOrigen,
    destino: paisDestino,
    montoIngresado: monto,
    montoCalculado: calcRedondeado,
    tasa: tasaF,
    fecha
  };

  const mensaje = mode === 'enviar'
    ? `<div class="text-sm italic text-gray-500 dark:text-gray-400">Enviando desde ${paisOrigen.nombre}</div>
       <div class="text-3xl font-semibold text-blue-800 dark:text-blue-400">$${montoFmt} ${paisOrigen.codigo}</div>
       <div class="text-base text-gray-600 dark:text-gray-300 mt-1">recibirás</div>
       <div class="text-4xl font-extrabold text-blue-900 dark:text-blue-200">${paisDestino.codigo} ${calcFmt}</div>
       <div class="text-sm italic text-gray-500 dark:text-gray-400 mt-4">Calculado con la tasa del día ${fecha} — <span class="font-semibold text-blue-800 dark:text-blue-400">${tasaFmt}</span></div>`
    : `<div class="text-sm italic text-gray-500 dark:text-gray-400">Para recibir en ${paisDestino.nombre}</div>
       <div class="text-3xl font-semibold text-blue-800 dark:text-blue-400">${paisDestino.codigo} ${montoFmt}</div>
       <div class="text-base text-gray-600 dark:text-gray-300 mt-1">debes enviar</div>
       <div class="text-4xl font-extrabold text-blue-900 dark:text-blue-200">$${calcFmt} ${paisOrigen.codigo}</div>
       <div class="text-sm italic text-gray-500 dark:text-gray-400 mt-4">Calculado con la tasa del día ${fecha} — <span class="font-semibold text-blue-800 dark:text-blue-400">${tasaFmt}</span></div>`;

  resText.innerHTML = mensaje;
  if (!soundSuccess.muted) soundSuccess.play();

  // No vaciamos el input aquí — el usuario puede querer ajustar el mismo valor
  step2.classList.add('hidden');
  tasaWrap.classList.add('transition', 'duration-500', 'ease-out', 'opacity-0', 'scale-95');
  setTimeout(() => tasaWrap.classList.add('hidden'), 500);

  loader.classList.remove('hidden');
  setTimeout(() => {
    loader.classList.add('hidden');
    resultado.classList.remove('hidden');
    resultado.classList.add('fade-scale-in');
    resText.classList.add('text-4xl');
  }, 1500);
};



btnRecalcular.onclick = () => {
  // Limpiezas comunes
  aceptoAdvertenciaPartes = false;
  resetearCampoMonto();

  resText.classList.remove('text-4xl');
  resultado.classList.add('hidden');
  resultado.classList.remove('fade-scale-in');

  // Caso 1: mismos países y mismo modo → volver a ingresar monto
  if (origenSeleccionado && destinoSeleccionado && mode) {
    lastCalc = null;
    estadoActual = 'monto';

    // Asegurar visibilidad de secciones correctas
    step1.classList.add('hidden');
    step2.classList.remove('hidden');
    tasaWrap.classList.remove('hidden');

    actualizarHeader('Ingresa el monto');
    // Refrescar textos (por si cambió algo de UI)
    actualizarTextosUI();

    // Foco y validación suave
    setTimeout(() => {
      inputMonto.focus();
      validarMontoEnVivo();
      tasaWrap.classList.remove('opacity-0', 'scale-95');
    }, 200);
    return;
  }

  // Caso 2: países elegidos pero aún sin modo → volver a elegir enviar/llegar
  if (origenSeleccionado && destinoSeleccionado) {
    lastCalc = null;
    estadoActual = 'modo';

    step2.classList.add('hidden');
    step1.classList.remove('hidden');
    tasaWrap.classList.remove('hidden');

    actualizarTextosUI();
    actualizarHeader('Selecciona el tipo de operación');

    setTimeout(() => {
      tasaWrap.classList.remove('opacity-0', 'scale-95');
    }, 50);
    return;
  }

  // Caso 3: reinicio total → elegir origen
  lastCalc = null;
  origenSeleccionado = null;
  destinoSeleccionado = null;
  mode = null;
  tasa = null;

  mostrarPaso1(); // ya gestiona header, botones y back
};


// --- WhatsApp ---
btnWhats.onclick = () => {
  if (!lastCalc) {
    mostrarToast('⚠️ Primero realiza un cálculo antes de enviar por WhatsApp');
    return;
  }

  const { mode, origen, destino, montoIngresado, montoCalculado, tasa, fecha } = lastCalc;
  const tasaFmt = formatearTasa(tasa);

  const ingresadoFmt = montoIngresado.toLocaleString('es-ES');
  const calculadoFmt = montoCalculado.toLocaleString('es-ES');

  const montoOrigenFmt = mode === 'enviar'
    ? `$${ingresadoFmt} ${origen.codigo}`
    : `$${calculadoFmt} ${origen.codigo}`;

  const montoDestinoFmt = mode === 'enviar'
    ? `${calculadoFmt} ${destino.codigo}`
    : `${ingresadoFmt} ${destino.codigo}`;

  const mensajeCliente =
    `👋 ¡Hola ByteTransfer!\n\n` +
    `Quiero enviar *${montoOrigenFmt}* desde *${origen.nombre}* ${origen.emoji} 📤\n` +
    `para que lleguen *${montoDestinoFmt}* a *${destino.nombre}* ${destino.emoji} 📬\n\n` +
    `💱 *Tasa del día:* ${tasaFmt}\n📅 *Fecha:* ${fecha}\n\n` +
    `¿Podrían ayudarme con esta transferencia? 🙏✨\n` +
    `Ya les paso el comprobante 📸✅`;

  const whatsappBtn = btnWhats;
  whatsappBtn.disabled = true;
  whatsappBtn.innerHTML = `
    <svg class="animate-spin h-5 w-5 mr-2 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
    </svg>
    Generando mensaje...`;

  setTimeout(() => {
    const url = `https://api.whatsapp.com/send?phone=${NUMERO_WHATSAPP}&text=${encodeURIComponent(mensajeCliente)}`;
    window.open(url, '_blank');
    whatsappBtn.disabled = false;
    whatsappBtn.innerHTML = 'Ir a WhatsApp';
  }, 600);
};

// --- Compartir ---
btnCompartir.onclick = (e) => {
  e.stopPropagation();
  btnCompartir.nextElementSibling.classList.remove('hidden');
};

opcionTexto.onclick = async () => {
  btnCompartir.nextElementSibling.classList.add('hidden');

  if (!lastCalc) {
    mostrarToast('⚠️ Primero realiza un cálculo antes de compartir');
    return;
  }

  const { mode, origen, destino, montoIngresado, montoCalculado, tasa, fecha } = lastCalc;
  const tasaFmt = formatearTasa(tasa);

  const ingresadoFmt = montoIngresado.toLocaleString('es-ES');
  const calculadoFmt = montoCalculado.toLocaleString('es-ES');

  const mensajePro =
    `📦 Transferencia calculada con ByteTransfer\n\n` +
    (mode === 'enviar'
      ? `💰 Monto a enviar: $${ingresadoFmt} ${origen.codigo} desde ${origen.nombre}\n` +
        `📥 Monto a recibir: ${destino.codigo} ${calculadoFmt} en ${destino.nombre}`
      : `📥 Monto a recibir: ${destino.codigo} ${ingresadoFmt} en ${destino.nombre}\n` +
        `💰 Monto a enviar: $${calculadoFmt} ${origen.codigo} desde ${origen.nombre}`) +
    `\n💱 Tasa del día: ${tasaFmt}\n📅 Fecha: ${fecha}`;

  try {
    await navigator.clipboard.writeText(mensajePro);
    mostrarToast('Texto copiado ✅');
  } catch (err) {
    mostrarToast('⚠️ Error al copiar');
    console.error(err);
  }
};


// Opción "📷 Compartir imagen" con carga a demanda
opcionImagen.onclick = async () => {
  // Cerrar menú
  btnCompartir.nextElementSibling.classList.add('hidden');

  // Validación como en compartir texto
  if (!lastCalc) {
    mostrarToast('⚠️ Primero realiza un cálculo antes de compartir');
    return;
  }

  // Feedback mientras se descarga la librería (solo la 1ª vez)
  const prevText = opcionImagen.textContent;
  opcionImagen.textContent = '📷 Cargando…';
  opcionImagen.disabled = true;

  try {
    const h2c = await ensureHtml2Canvas();

    // Captura y armado del archivo (igual que antes)
    const canvas = await h2c(resTextContainer, { scale: 2, useCORS: true, backgroundColor: '#ffffff' });
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
    const file = new File([blob], 'byte-transfer-result.png', { type: 'image/png' });

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          title: 'ByteTransfer',
          text: 'Resultado de cambio enviado desde la app ByteTransfer',
          files: [file]
        });
      } catch (err) {
        console.warn('Share cancelado o falló:', err);
      }
    } else {
      const link = document.createElement('a');
      link.download = 'byte-transfer-result.png';
      link.href = canvas.toDataURL();
      link.click();
    }
  } catch (err) {
    console.error(err);
    mostrarToast('⚠️ No se pudo cargar el módulo de imagen. Reintenta.');
  } finally {
    opcionImagen.textContent = prevText;
    opcionImagen.disabled = false;
  }
};


document.addEventListener('click', e => {
  const menu = btnCompartir.nextElementSibling;
  if (!menu.contains(e.target) && e.target !== btnCompartir) {
    menu.classList.add('hidden');
  }
});

// Ripple por delegación (funciona con botones creados dinámicamente)
document.addEventListener('click', e => {
  const btn = e.target.closest('.ripple-button');
  if (!btn) return;
  const ripple = document.createElement('span');
  const d = Math.max(btn.clientWidth, btn.clientHeight);
  const r = d / 2;
  ripple.style.width = ripple.style.height = `${d}px`;
  const rect = btn.getBoundingClientRect();
  ripple.style.left = `${e.clientX - rect.left - r}px`;
  ripple.style.top = `${e.clientY - rect.top - r}px`;
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

// Toast
function mostrarToast(txt) {
  toastMensaje.textContent = txt;
  toastMensaje.classList.remove('hidden');
  toastMensaje.style.opacity = '1';
  toastMensaje.style.transform = 'scale(1)';
  setTimeout(() => {
    toastMensaje.style.opacity = '0';
    toastMensaje.style.transform = 'scale(0.95)';
    setTimeout(() => {
      toastMensaje.classList.add('hidden');
      toastMensaje.textContent = '';
    }, 300);
  }, 4500);
}

// Onload
window.onload = () => {
  mainHeader.classList.add('hidden');
  document.getElementById('tasaWrap').classList.add('hidden');
  step1.classList.add('hidden');
  step2.classList.add('hidden');
  resultado.classList.add('hidden');
  step2Destino.classList.add('hidden');
  step1Origen.classList.remove('hidden');
  mostrarPaso1();
};