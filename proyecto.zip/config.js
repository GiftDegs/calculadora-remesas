﻿export const CONFIG = { MIN_USD: 5, MAX_USD: 1000 };
export const NUMERO_WHATSAPP = "5491157261053";
export const paisesDisponibles = [
  { codigo: "ARS", nombre: "Argentina", emoji: "🇦🇷", moneda: "pesos argentinos" },
  { codigo: "COP", nombre: "Colombia",  emoji: "🇨🇴", moneda: "pesos colombianos" },
  { codigo: "PEN", nombre: "Perú",      emoji: "🇵🇪", moneda: "soles" },
  { codigo: "CLP", nombre: "Chile",     emoji: "🇨🇱", moneda: "pesos chilenos" },
  { codigo: "MXN", nombre: "México",    emoji: "🇲🇽", moneda: "pesos mexicanos" },
  { codigo: "BRL", nombre: "Brasil",    emoji: "🇧🇷", moneda: "reales" },
  { codigo: "VES", nombre: "Venezuela", emoji: "🇻🇪", moneda: "bolívares" }
];
